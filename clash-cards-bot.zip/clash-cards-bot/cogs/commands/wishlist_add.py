"""/cards wishlist add <card> — mark a card as one you're prioritizing for trades."""

from discord import app_commands, Interaction

from . import wishlist_group
from cogs.utils import card_autocomplete
from data.catalog import get_card, category_emoji
from db.database import db


@wishlist_group.command(name="add", description="Add a card to your trade wishlist")
@app_commands.describe(card="Card name")
@app_commands.autocomplete(card=card_autocomplete)
async def wishlist_add_cmd(interaction: Interaction, card: str):
    found = get_card(card)
    if found is None:
        await interaction.response.send_message(
            f"Couldn't find a card called **{card}** — pick one from the autocomplete list.",
            ephemeral=True,
        )
        return

    added = await db.wishlist_add(interaction.guild_id, interaction.user.id, found.id)
    if added:
        msg = f"{category_emoji(found.category)} Added **{found.name}** to your wishlist."
    else:
        msg = f"**{found.name}** is already on your wishlist."
    await interaction.response.send_message(msg, ephemeral=True)
