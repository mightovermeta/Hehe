"""
Defines the top-level `/cards` group and its `wishlist` / `offer` subgroups,
then imports every command module so their `@cards_group.command(...)` /
`@wishlist_group.command(...)` / `@offer_group.command(...)` decorators run
and register the commands onto these group objects.

Each cogs/commands/*.py file is a single command — see that file for its
docstring. This __init__ is just the wiring; add a new command by creating
a new module here and adding one import line below.
"""

from discord import app_commands
from discord.ext import commands

cards_group = app_commands.Group(
    name="cards", description="Track and trade your Clashiversary card collection"
)
wishlist_group = app_commands.Group(
    name="wishlist", description="Manage your card wishlist", parent=cards_group
)
offer_group = app_commands.Group(
    name="offer", description="Manage cards you have spare to trade", parent=cards_group
)

# Importing these triggers each module's command registration (side effect of
# the @group.command decorator running at import time). Order doesn't matter.
from . import card_set  # noqa: E402, F401
from . import card_add  # noqa: E402, F401
from . import card_collection  # noqa: E402, F401
from . import card_progress  # noqa: E402, F401
from . import card_leaderboard  # noqa: E402, F401
from . import card_reset  # noqa: E402, F401
from . import wishlist_add  # noqa: E402, F401
from . import wishlist_remove  # noqa: E402, F401
from . import wishlist_list  # noqa: E402, F401
from . import offer_add  # noqa: E402, F401
from . import offer_remove  # noqa: E402, F401
from . import offer_list  # noqa: E402, F401
from . import swap  # noqa: E402, F401


class CardsCog(commands.Cog):
    """Empty cog whose only job is to give load_extension something to hang the group off of."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CardsCog(bot))
    bot.tree.add_command(cards_group)
