"""/cards progress [user] — progress bars per category + overall total."""

from discord import app_commands, Interaction, User

from . import cards_group
from cogs.views import ProgressView
from db.database import db


@cards_group.command(name="progress", description="See progress toward completing each card category")
@app_commands.describe(user="Whose progress to view (defaults to you)")
async def cards_progress(interaction: Interaction, user: User = None):
    target = user or interaction.user
    progress = await db.get_progress(interaction.guild_id, target.id)
    view = ProgressView(target, progress)
    await interaction.response.send_message(view=view)
