"""
Central place for reading configuration out of the environment.
Loads a .env file (if python-dotenv is installed and a .env exists) so local
dev works without exporting vars manually; in production just set real
environment variables and this still works.
"""

import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass  # dotenv is optional; fine in prod where env vars are set directly


def _get_int(name: str) -> int | None:
    val = os.getenv(name)
    if val is None or val.strip() == "":
        return None
    try:
        return int(val)
    except ValueError:
        raise RuntimeError(f"Environment variable {name}='{val}' is not a valid integer")


class Config:
    DISCORD_TOKEN: str = os.getenv("DISCORD_TOKEN", "")
    DATABASE_URL: str = os.getenv("DATABASE_URL", "")

    # Optional: set this to a guild ID while developing so slash commands
    # sync instantly to that one server instead of taking up to an hour to
    # propagate globally. Leave unset in production for a global sync.
    DEV_GUILD_ID: int | None = _get_int("DEV_GUILD_ID")

    # How many rows to show per page in paginated views (collection, leaderboard)
    PAGE_SIZE: int = _get_int("PAGE_SIZE") or 10

    @classmethod
    def validate(cls) -> None:
        missing = []
        if not cls.DISCORD_TOKEN:
            missing.append("DISCORD_TOKEN")
        if not cls.DATABASE_URL:
            missing.append("DATABASE_URL")
        if missing:
            raise RuntimeError(
                f"Missing required environment variable(s): {', '.join(missing)}. "
                f"Copy .env.example to .env and fill them in."
            )


config = Config()
