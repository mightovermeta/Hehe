"""
Thin async data-access layer over a single asyncpg pool.

Usage:
    from db.database import db
    await db.connect(dsn)       # once, in bot.setup_hook
    rows = await db.get_collection(guild_id, user_id)
    ...
    await db.close()            # once, on shutdown
"""

from __future__ import annotations

import asyncpg

from data.catalog import TOTAL_CARDS


class Database:
    def __init__(self) -> None:
        self.pool: asyncpg.Pool | None = None

    async def connect(self, dsn: str) -> None:
        self.pool = await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=10)

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()

    def _require_pool(self) -> asyncpg.Pool:
        if self.pool is None:
            raise RuntimeError("Database.connect() must be called before running queries")
        return self.pool

    # ---------------------------------------------------------------- #
    # Collection
    # ---------------------------------------------------------------- #

    async def get_collection(self, guild_id: int, user_id: int) -> dict[int, int]:
        """Returns {card_id: count} for every card the user owns at least one of."""
        pool = self._require_pool()
        rows = await pool.fetch(
            """
            SELECT card_id, count FROM card_collections
            WHERE guild_id = $1 AND user_id = $2 AND count > 0
            """,
            guild_id,
            user_id,
        )
        return {r["card_id"]: r["count"] for r in rows}

    async def get_card_count(self, guild_id: int, user_id: int, card_id: int) -> int:
        pool = self._require_pool()
        val = await pool.fetchval(
            "SELECT count FROM card_collections WHERE guild_id = $1 AND user_id = $2 AND card_id = $3",
            guild_id,
            user_id,
            card_id,
        )
        return val or 0

    async def set_card_count(self, guild_id: int, user_id: int, card_id: int, count: int) -> int:
        """Set a card's count to an exact value (min 0). Returns the new count."""
        count = max(0, count)
        pool = self._require_pool()
        await pool.execute(
            """
            INSERT INTO card_collections (guild_id, user_id, card_id, count, updated_at)
            VALUES ($1, $2, $3, $4, now())
            ON CONFLICT (guild_id, user_id, card_id)
            DO UPDATE SET count = $4, updated_at = now()
            """,
            guild_id,
            user_id,
            card_id,
            count,
        )
        return count

    async def add_card_count(self, guild_id: int, user_id: int, card_id: int, amount: int) -> int:
        """Increment (or decrement, if amount is negative) a card's count, floored at 0."""
        pool = self._require_pool()
        new_count = await pool.fetchval(
            """
            INSERT INTO card_collections (guild_id, user_id, card_id, count, updated_at)
            VALUES ($1, $2, $3, GREATEST(0, $4), now())
            ON CONFLICT (guild_id, user_id, card_id)
            DO UPDATE SET count = GREATEST(0, card_collections.count + $4), updated_at = now()
            RETURNING count
            """,
            guild_id,
            user_id,
            card_id,
            amount,
        )
        return new_count

    async def reset_collection(self, guild_id: int, user_id: int) -> None:
        pool = self._require_pool()
        await pool.execute(
            "DELETE FROM card_collections WHERE guild_id = $1 AND user_id = $2",
            guild_id,
            user_id,
        )

    async def get_progress(self, guild_id: int, user_id: int) -> dict:
        """Returns unique-card progress overall and per category."""
        from data.catalog import CARDS_BY_CATEGORY, CATEGORY_ORDER

        owned = await self.get_collection(guild_id, user_id)
        owned_ids = set(owned.keys())

        per_category = {}
        for cat in CATEGORY_ORDER:
            cat_card_ids = {c.id for c in CARDS_BY_CATEGORY[cat]}
            owned_in_cat = len(owned_ids & cat_card_ids)
            per_category[cat] = {"owned": owned_in_cat, "total": len(cat_card_ids)}

        return {
            "owned_unique": len(owned_ids),
            "total_unique": TOTAL_CARDS,
            "total_count": sum(owned.values()),
            "per_category": per_category,
        }

    # ---------------------------------------------------------------- #
    # Leaderboard
    # ---------------------------------------------------------------- #

    async def get_leaderboard(self, guild_id: int, limit: int = 10) -> list[dict]:
        """Top users by unique cards owned (ties broken by total cards owned)."""
        pool = self._require_pool()
        rows = await pool.fetch(
            """
            SELECT user_id,
                   COUNT(*) FILTER (WHERE count > 0) AS unique_count,
                   COALESCE(SUM(count), 0) AS total_count
            FROM card_collections
            WHERE guild_id = $1
            GROUP BY user_id
            HAVING COUNT(*) FILTER (WHERE count > 0) > 0
            ORDER BY unique_count DESC, total_count DESC
            LIMIT $2
            """,
            guild_id,
            limit,
        )
        return [dict(r) for r in rows]

    # ---------------------------------------------------------------- #
    # Wishlist
    # ---------------------------------------------------------------- #

    async def wishlist_add(self, guild_id: int, user_id: int, card_id: int) -> bool:
        """Returns True if added, False if it was already on the wishlist."""
        pool = self._require_pool()
        result = await pool.execute(
            """
            INSERT INTO card_wishlist (guild_id, user_id, card_id)
            VALUES ($1, $2, $3)
            ON CONFLICT (guild_id, user_id, card_id) DO NOTHING
            """,
            guild_id,
            user_id,
            card_id,
        )
        return result.endswith("1")

    async def wishlist_remove(self, guild_id: int, user_id: int, card_id: int) -> bool:
        pool = self._require_pool()
        result = await pool.execute(
            "DELETE FROM card_wishlist WHERE guild_id = $1 AND user_id = $2 AND card_id = $3",
            guild_id,
            user_id,
            card_id,
        )
        return result.endswith("1")

    async def wishlist_list(self, guild_id: int, user_id: int) -> list[int]:
        pool = self._require_pool()
        rows = await pool.fetch(
            "SELECT card_id FROM card_wishlist WHERE guild_id = $1 AND user_id = $2 ORDER BY created_at",
            guild_id,
            user_id,
        )
        return [r["card_id"] for r in rows]

    # ---------------------------------------------------------------- #
    # Offers (swap shop)
    # ---------------------------------------------------------------- #

    async def offer_add(self, guild_id: int, user_id: int, card_id: int) -> bool:
        pool = self._require_pool()
        result = await pool.execute(
            """
            INSERT INTO card_offers (guild_id, user_id, card_id)
            VALUES ($1, $2, $3)
            ON CONFLICT (guild_id, user_id, card_id) DO NOTHING
            """,
            guild_id,
            user_id,
            card_id,
        )
        return result.endswith("1")

    async def offer_remove(self, guild_id: int, user_id: int, card_id: int) -> bool:
        pool = self._require_pool()
        result = await pool.execute(
            "DELETE FROM card_offers WHERE guild_id = $1 AND user_id = $2 AND card_id = $3",
            guild_id,
            user_id,
            card_id,
        )
        return result.endswith("1")

    async def offer_list(self, guild_id: int, user_id: int) -> list[int]:
        pool = self._require_pool()
        rows = await pool.fetch(
            "SELECT card_id FROM card_offers WHERE guild_id = $1 AND user_id = $2 ORDER BY created_at",
            guild_id,
            user_id,
        )
        return [r["card_id"] for r in rows]

    # ---------------------------------------------------------------- #
    # Swap matching
    # ---------------------------------------------------------------- #

    async def find_direct_swap(self, guild_id: int, user_id: int, other_id: int) -> dict:
        """
        Cards user_id offers that other_id wants, and vice versa —
        the two-person "do we have a trade" check used by /cards swap.
        """
        pool = self._require_pool()
        they_get = await pool.fetch(
            """
            SELECT o.card_id FROM card_offers o
            JOIN card_wishlist w
              ON w.guild_id = o.guild_id AND w.card_id = o.card_id AND w.user_id = $3
            WHERE o.guild_id = $1 AND o.user_id = $2
            """,
            guild_id,
            user_id,
            other_id,
        )
        you_get = await pool.fetch(
            """
            SELECT o.card_id FROM card_offers o
            JOIN card_wishlist w
              ON w.guild_id = o.guild_id AND w.card_id = o.card_id AND w.user_id = $3
            WHERE o.guild_id = $1 AND o.user_id = $2
            """,
            guild_id,
            other_id,
            user_id,
        )
        return {
            "you_give": [r["card_id"] for r in they_get],
            "you_get": [r["card_id"] for r in you_get],
        }

    async def find_swap_candidates(self, guild_id: int, user_id: int, limit: int = 15) -> list[dict]:
        """
        Server-wide scan: for every other user, count how many cards they
        offer that user_id wants, plus how many cards user_id offers that
        they want. Sorted by total mutual matches, mutual trades first.
        """
        pool = self._require_pool()
        rows = await pool.fetch(
            """
            WITH my_wants AS (
                SELECT card_id FROM card_wishlist WHERE guild_id = $1 AND user_id = $2
            ),
            my_offers AS (
                SELECT card_id FROM card_offers WHERE guild_id = $1 AND user_id = $2
            ),
            they_give_me AS (
                SELECT o.user_id, array_agg(o.card_id) AS card_ids
                FROM card_offers o
                JOIN my_wants w ON w.card_id = o.card_id
                WHERE o.guild_id = $1 AND o.user_id != $2
                GROUP BY o.user_id
            ),
            i_give_them AS (
                SELECT w.user_id, array_agg(w.card_id) AS card_ids
                FROM card_wishlist w
                JOIN my_offers o ON o.card_id = w.card_id
                WHERE w.guild_id = $1 AND w.user_id != $2
                GROUP BY w.user_id
            )
            SELECT
                COALESCE(g.user_id, t.user_id) AS user_id,
                COALESCE(g.card_ids, ARRAY[]::int[]) AS they_offer_you_want,
                COALESCE(t.card_ids, ARRAY[]::int[]) AS you_offer_they_want
            FROM they_give_me g
            FULL OUTER JOIN i_give_them t ON t.user_id = g.user_id
            ORDER BY
                (COALESCE(array_length(g.card_ids, 1), 0) > 0
                 AND COALESCE(array_length(t.card_ids, 1), 0) > 0) DESC,
                (COALESCE(array_length(g.card_ids, 1), 0) + COALESCE(array_length(t.card_ids, 1), 0)) DESC
            LIMIT $3
            """,
            guild_id,
            user_id,
            limit,
        )
        return [dict(r) for r in rows]


db = Database()
