"""/cards leaderboard — top collectors in the server by unique cards owned."""

from discord import app_commands, Interaction

from . import cards_group
from cogs.views import LeaderboardView
from db.database import db


@cards_group.command(name="leaderboard", description="See who's collected the most unique cards in this server")
async def cards_leaderboard(interaction: Interaction):
    await interaction.response.defer()
    rows = await db.get_leaderboard(interaction.guild_id, limit=10)

    # Resolve display names up front so the view doesn't need to await anything
    names: dict[int, str] = {}
    for row in rows:
        member = interaction.guild.get_member(row["user_id"])
        if member is None:
            try:
                member = await interaction.guild.fetch_member(row["user_id"])
            except Exception:
                member = None
        names[row["user_id"]] = member.display_name if member else f"Unknown user ({row['user_id']})"

    view = LeaderboardView(interaction.guild.name, rows, resolve_name=lambda uid: names.get(uid, str(uid)))
    await interaction.followup.send(view=view)
