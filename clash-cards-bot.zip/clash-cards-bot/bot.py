"""
Entry point. Run with: python bot.py

Responsible for: building the bot, connecting the DB pool on startup and
closing it on shutdown, loading the cogs.commands extension (which registers
/cards and its subcommands), and syncing the command tree.
"""

import asyncio
import logging

import discord
from discord.ext import commands

from config import config
from db.database import db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("clash-cards-bot")

INTENTS = discord.Intents.default()
# We don't read message content or need member presence — slash commands +
# guild member lookups (for display names) are all this bot needs.
INTENTS.members = True


class ClashCardsBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=commands.when_mentioned, intents=INTENTS)

    async def setup_hook(self):
        config.validate()

        log.info("Connecting to database…")
        await db.connect(config.DATABASE_URL)

        log.info("Loading extensions…")
        await self.load_extension("cogs.commands")

        if config.DEV_GUILD_ID:
            guild = discord.Object(id=config.DEV_GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %d command(s) to dev guild %s", len(synced), config.DEV_GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Synced %d command(s) globally (can take up to ~1hr to propagate)", len(synced))

    async def close(self):
        await db.close()
        await super().close()


bot = ClashCardsBot()


@bot.event
async def on_ready():
    log.info("Logged in as %s (id=%s)", bot.user, bot.user.id)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
    log.exception("Command error in /%s", getattr(interaction.command, "qualified_name", "?"), exc_info=error)
    msg = "Something went wrong running that command. Please try again."
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


def main():
    config.validate()
    bot.run(config.DISCORD_TOKEN, log_handler=None)


if __name__ == "__main__":
    main()
