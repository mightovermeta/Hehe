-- Clash Cards bot schema (PostgreSQL)
-- Run once: psql "$DATABASE_URL" -f db/schema.sql

-- How many of each card a user owns, per guild (scoped per-server since
-- collections in-game aren't shared across the Discord servers a person is in,
-- but this keeps trade-matching relevant to a single server's members).
CREATE TABLE IF NOT EXISTS card_collections (
    guild_id   BIGINT      NOT NULL,
    user_id    BIGINT      NOT NULL,
    card_id    INTEGER     NOT NULL,
    count      INTEGER     NOT NULL DEFAULT 0 CHECK (count >= 0),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (guild_id, user_id, card_id)
);

CREATE INDEX IF NOT EXISTS idx_collections_lookup
    ON card_collections (guild_id, user_id);

-- Cards a user wants (priority wishlist, used for swap matching)
CREATE TABLE IF NOT EXISTS card_wishlist (
    guild_id   BIGINT      NOT NULL,
    user_id    BIGINT      NOT NULL,
    card_id    INTEGER     NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (guild_id, user_id, card_id)
);

CREATE INDEX IF NOT EXISTS idx_wishlist_lookup
    ON card_wishlist (guild_id, user_id);

CREATE INDEX IF NOT EXISTS idx_wishlist_by_card
    ON card_wishlist (guild_id, card_id);

-- Cards a user has spare and is offering up for trade (the "Swap Shop")
CREATE TABLE IF NOT EXISTS card_offers (
    guild_id   BIGINT      NOT NULL,
    user_id    BIGINT      NOT NULL,
    card_id    INTEGER     NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (guild_id, user_id, card_id)
);

CREATE INDEX IF NOT EXISTS idx_offers_lookup
    ON card_offers (guild_id, user_id);

CREATE INDEX IF NOT EXISTS idx_offers_by_card
    ON card_offers (guild_id, card_id);
