# Clash Cards Bot

A Discord bot for tracking your Clash of Clans Clashiversary card collection
and trading with other server members — built around the same 60-card
catalog as [clash.ninja/cards](https://www.clash.ninja/cards).

## Commands

| Command | Description |
|---|---|
| `/cards set <card> <count>` | Set exactly how many of a card you own |
| `/cards add <card> [amount]` | Add to a card's count (default +1) |
| `/cards collection [user]` | Browse a collection, category by category |
| `/cards progress [user]` | Progress bars per category + overall |
| `/cards leaderboard` | Top collectors in the server |
| `/cards reset` | Wipe your whole collection (confirms first) |
| `/cards wishlist add/remove/list [user]` | Manage cards you want |
| `/cards offer add/remove/list [user]` | Manage spare cards you'll trade away |
| `/cards swap [user]` | Check a trade with one user, or scan the server for matches |

## Setup

**1. Requirements**
- Python 3.11+
- A PostgreSQL database (local, RDS, Supabase, Railway, etc.)
- A Discord bot application ([discord.com/developers/applications](https://discord.com/developers/applications)) with the **Server Members Intent** enabled in the bot's settings, and invited to your server with the `applications.commands` and `bot` scopes.

**2. Install dependencies**
```bash
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**3. Configure**
```bash
cp .env.example .env
```
Fill in `DISCORD_TOKEN` and `DATABASE_URL`. Set `DEV_GUILD_ID` to your test
server's ID while developing so slash commands show up instantly instead of
waiting for the global sync.

**4. Create the database schema**
```bash
psql "$DATABASE_URL" -f db/schema.sql
```

**5. Run it**
```bash
python bot.py
```

## Project layout

```
clash-cards-bot/
├── bot.py                  # entry point: builds the bot, connects the DB, loads cogs, syncs commands
├── config.py                # env var loading
├── data/
│   └── catalog.py            # the 60-card catalog (id, name, category)
├── db/
│   ├── schema.sql             # table definitions
│   └── database.py             # asyncpg pool + every query the bot runs
└── cogs/
    ├── utils.py                # autocomplete, progress-bar rendering, small helpers
    ├── views.py                 # Components V2 layouts (Container/Section/TextDisplay)
    └── commands/
        ├── __init__.py           # registers the /cards group + wishlist/offer subgroups
        └── *.py                   # one file per command
```

## Notes

- Collections are scoped **per server** — someone's card counts in Server A
  are independent from Server B. This keeps `/cards leaderboard` and
  `/cards swap` meaningful to one community rather than mixing everyone a
  user happens to share a server with.
- `/cards swap` without a target user does a full scan of everyone in the
  server who has offers/wishlist entries and ranks mutual matches first.
- The Components V2 layouts in `cogs/views.py` need **discord.py 2.6+**
  (that's where `discord.ui.LayoutView`, `Container`, `Section`, and
  `TextDisplay` shipped). If commands error out with an `AttributeError` on
  one of those names, run `pip install -U discord.py`.
- If Supercell rotates the card set in a future event, everything reads from
  `data/catalog.py` — update the lists there and the rest of the bot follows.
