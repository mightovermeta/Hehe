"""/cards offer add <card> — list a spare/duplicate card as available to trade."""

from discord import app_commands, Interaction

from . import offer_group
from cogs.utils import card_autocomplete
from data.catalog import get_card, category_emoji
from db.database import db


@offer_group.command(name="add", description="Offer up a spare card for trade in the Swap Shop")
@app_commands.describe(card="Card name")
@app_commands.autocomplete(card=card_autocomplete)
async def offer_add_cmd(interaction: Interaction, card: str):
    found = get_card(card)
    if found is None:
        await interaction.response.send_message(
            f"Couldn't find a card called **{card}** — pick one from the autocomplete list.",
            ephemeral=True,
        )
        return

    added = await db.offer_add(interaction.guild_id, interaction.user.id, found.id)
    if added:
        msg = f"{category_emoji(found.category)} **{found.name}** is now offered up for trade."
    else:
        msg = f"**{found.name}** is already in your offers."
    await interaction.response.send_message(msg, ephemeral=True)
