"""/cards set <card> <count> — set the exact number of a card you own."""

from discord import app_commands, Interaction

from . import cards_group
from cogs.utils import card_autocomplete
from data.catalog import get_card, category_emoji
from db.database import db


@cards_group.command(name="set", description="Set exactly how many of a card you own")
@app_commands.describe(card="Card name", count="How many you own (0 to mark it as not owned)")
@app_commands.autocomplete(card=card_autocomplete)
async def cards_set(interaction: Interaction, card: str, count: app_commands.Range[int, 0, 999]):
    found = get_card(card)
    if found is None:
        await interaction.response.send_message(
            f"Couldn't find a card called **{card}** — pick one from the autocomplete list.",
            ephemeral=True,
        )
        return

    new_count = await db.set_card_count(interaction.guild_id, interaction.user.id, found.id, count)
    await interaction.response.send_message(
        f"{category_emoji(found.category)} Set **{found.name}** to **{new_count}**.",
        ephemeral=True,
    )
