"""/cards wishlist list [user] — show everything on someone's wishlist."""

from discord import app_commands, Interaction, User

from . import wishlist_group
from data.catalog import get_card, category_emoji
from db.database import db


@wishlist_group.command(name="list", description="See your (or someone else's) trade wishlist")
@app_commands.describe(user="Whose wishlist to view (defaults to you)")
async def wishlist_list_cmd(interaction: Interaction, user: User = None):
    target = user or interaction.user
    card_ids = await db.wishlist_list(interaction.guild_id, target.id)

    if not card_ids:
        await interaction.response.send_message(
            f"{target.display_name}'s wishlist is empty." if user else "Your wishlist is empty — add cards with `/cards wishlist add`.",
            ephemeral=True,
        )
        return

    lines = []
    for cid in card_ids:
        c = get_card(cid)
        if c:
            lines.append(f"{category_emoji(c.category)} {c.name}")

    await interaction.response.send_message(
        f"### 💭 {target.display_name}'s Wishlist\n" + "\n".join(lines)
    )
