"""
/cards swap [user] — trade finder.

- With a user given: direct check of what you two could swap based on
  each other's offers vs wishlists.
- Without a user: scans the whole server for the best matches based on
  your own offers and wishlist.
"""

from discord import app_commands, Interaction, User

from . import cards_group
from cogs.views import SwapResultView, SwapCandidatesView
from data.catalog import get_card
from db.database import db


@cards_group.command(name="swap", description="Find a trade — check against one user, or scan the whole server")
@app_commands.describe(user="Check a specific trade partner (omit to scan the whole server)")
async def cards_swap(interaction: Interaction, user: User = None):
    await interaction.response.defer()

    if user is not None:
        if user.id == interaction.user.id:
            await interaction.followup.send("You can't swap with yourself!", ephemeral=True)
            return

        result = await db.find_direct_swap(interaction.guild_id, interaction.user.id, user.id)
        you_give = [c for cid in result["you_give"] if (c := get_card(cid))]
        you_get = [c for cid in result["you_get"] if (c := get_card(cid))]
        view = SwapResultView(interaction.user, user, you_give, you_get)
        await interaction.followup.send(view=view)
        return

    candidates = await db.find_swap_candidates(interaction.guild_id, interaction.user.id)

    names: dict[int, str] = {}
    for cand in candidates:
        uid = cand["user_id"]
        member = interaction.guild.get_member(uid)
        if member is None:
            try:
                member = await interaction.guild.fetch_member(uid)
            except Exception:
                member = None
        names[uid] = member.display_name if member else f"Unknown user ({uid})"

    view = SwapCandidatesView(interaction.user, candidates, resolve_name=lambda uid: names.get(uid, str(uid)))
    await interaction.followup.send(view=view)
