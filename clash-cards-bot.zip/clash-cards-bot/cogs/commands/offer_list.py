"""/cards offer list [user] — show everything someone has offered up for trade."""

from discord import app_commands, Interaction, User

from . import offer_group
from data.catalog import get_card, category_emoji
from db.database import db


@offer_group.command(name="list", description="See your (or someone else's) trade offers")
@app_commands.describe(user="Whose offers to view (defaults to you)")
async def offer_list_cmd(interaction: Interaction, user: User = None):
    target = user or interaction.user
    card_ids = await db.offer_list(interaction.guild_id, target.id)

    if not card_ids:
        await interaction.response.send_message(
            f"{target.display_name} hasn't offered any cards." if user else "You haven't offered any cards yet — add some with `/cards offer add`.",
            ephemeral=True,
        )
        return

    lines = []
    for cid in card_ids:
        c = get_card(cid)
        if c:
            lines.append(f"{category_emoji(c.category)} {c.name}")

    await interaction.response.send_message(
        f"### 📤 {target.display_name}'s Trade Offers\n" + "\n".join(lines)
    )
