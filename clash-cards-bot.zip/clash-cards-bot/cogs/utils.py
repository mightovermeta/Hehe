"""Small shared helpers used across the /cards command modules."""

from __future__ import annotations

from discord import app_commands, Interaction

from data.catalog import CARDS, category_emoji


async def card_autocomplete(interaction: Interaction, current: str) -> list[app_commands.Choice[str]]:
    """Autocomplete for any 'card' option: matches on substring, case-insensitive."""
    current = current.lower().strip()
    matches = [c for c in CARDS if current in c.name.lower()] if current else list(CARDS)
    matches.sort(key=lambda c: (not c.name.lower().startswith(current), c.category, c.name))
    return [
        app_commands.Choice(name=f"{category_emoji(c.category)} {c.name}", value=c.name)
        for c in matches[:25]
    ]


def progress_bar(owned: int, total: int, length: int = 12) -> str:
    """Renders a text progress bar, e.g. '████████░░░░ 8/12'."""
    total = max(total, 1)
    filled = round(length * (owned / total))
    filled = min(filled, length)
    bar = "█" * filled + "░" * (length - filled)
    return f"`{bar}` {owned}/{total}"


def format_card_line(name: str, category: str, count: int) -> str:
    """One line for a card in a list: emoji, name, and count/dupe indicator."""
    emoji = category_emoji(category)
    if count <= 0:
        return f"{emoji} ~~{name}~~"
    dupe_note = f" (x{count})" if count > 1 else ""
    return f"{emoji} **{name}**{dupe_note}"


def chunk(items: list, size: int) -> list[list]:
    return [items[i : i + size] for i in range(0, len(items), size)]
