"""
Static card catalog for the Clashiversary card collection event.
Source: https://www.clash.ninja/cards (60 total cards across 4 categories).

If Supercell adds/rotates cards in a future event, update the lists below —
everything else in the bot (autocomplete, progress bars, DB checks) reads
from this file, so nothing else needs to change.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Card:
    id: int  # stable internal id == in-game entity id, used as the DB primary key
    name: str
    category: str  # one of CATEGORY_ORDER keys

    @property
    def icon_url(self) -> str:
        return f"https://www.clash.ninja/images/entities/{self.id}_icon.png"


# Category machine-name -> display name + emoji shown in embeds/components
CATEGORY_INFO = {
    "elixir": {"label": "Elixir Cards", "emoji": "💧"},
    "dark_elixir": {"label": "Dark Elixir Cards", "emoji": "🟣"},
    "builder_base": {"label": "Builder Base Cards", "emoji": "🔨"},
    "super_troop": {"label": "Super Troop Cards", "emoji": "⚡"},
}

CATEGORY_ORDER = ["elixir", "dark_elixir", "builder_base", "super_troop"]

_RAW_CARDS: list[tuple[int, str, str]] = [
    # -- Elixir Cards (19) --
    (31, "Barbarian", "elixir"),
    (32, "Archer", "elixir"),
    (33, "Giant", "elixir"),
    (34, "Goblin", "elixir"),
    (35, "Wall Breaker", "elixir"),
    (36, "Balloon", "elixir"),
    (37, "Wizard", "elixir"),
    (38, "Healer", "elixir"),
    (39, "Dragon", "elixir"),
    (40, "PEKKA", "elixir"),
    (41, "Baby Dragon", "elixir"),
    (42, "Miner", "elixir"),
    (103, "Electro Dragon", "elixir"),
    (121, "Yeti", "elixir"),
    (133, "Dragon Rider", "elixir"),
    (138, "Electro Titan", "elixir"),
    (156, "Root Rider", "elixir"),
    (204, "Thrower", "elixir"),
    (241, "Meteor Golem", "elixir"),
    # -- Dark Elixir Cards (13) --
    (53, "Minion", "dark_elixir"),
    (54, "Hog Rider", "dark_elixir"),
    (55, "Valkyrie", "dark_elixir"),
    (56, "Golem", "dark_elixir"),
    (57, "Witch", "dark_elixir"),
    (58, "Lava Hound", "dark_elixir"),
    (59, "Bowler", "dark_elixir"),
    (111, "Ice Golem", "dark_elixir"),
    (123, "Headhunter", "dark_elixir"),
    (151, "Apprentice Warden", "dark_elixir"),
    (197, "Druid", "dark_elixir"),
    (218, "Furnace", "dark_elixir"),
    (282, "Rubble Witch", "dark_elixir"),
    # -- Builder Base Cards (11) --
    (90, "Raged Barbarian", "builder_base"),
    (91, "Sneaky Archer", "builder_base"),
    (92, "Boxer Giant", "builder_base"),
    (93, "Beta Minion", "builder_base"),
    (94, "Bomber", "builder_base"),
    (95, "BB Baby Dragon", "builder_base"),
    (96, "Cannon Cart", "builder_base"),
    (97, "Night Witch", "builder_base"),
    (98, "Drop Ship", "builder_base"),
    (101, "Power PEKKA", "builder_base"),
    (113, "Hog Glider", "builder_base"),
    # -- Super Troop Cards (17) --
    (177, "Super Barbarian", "super_troop"),
    (178, "Super Archer", "super_troop"),
    (179, "Super Giant", "super_troop"),
    (180, "Sneaky Goblin", "super_troop"),
    (181, "Super Wall Breaker", "super_troop"),
    (182, "Rocket Balloon", "super_troop"),
    (183, "Super Wizard", "super_troop"),
    (184, "Super Dragon", "super_troop"),
    (185, "Inferno Dragon", "super_troop"),
    (191, "Super Miner", "super_troop"),
    (221, "Super Yeti", "super_troop"),
    (186, "Super Minion", "super_troop"),
    (192, "Super Hog Rider", "super_troop"),
    (187, "Super Valkyrie", "super_troop"),
    (188, "Super Witch", "super_troop"),
    (189, "Ice Hound", "super_troop"),
    (190, "Super Bowler", "super_troop"),
]

CARDS: list[Card] = [Card(id=i, name=n, category=c) for i, n, c in _RAW_CARDS]
CARDS_BY_ID: dict[int, Card] = {c.id: c for c in CARDS}
CARDS_BY_NAME: dict[str, Card] = {c.name.lower(): c for c in CARDS}

CARDS_BY_CATEGORY: dict[str, list[Card]] = {cat: [] for cat in CATEGORY_ORDER}
for _c in CARDS:
    CARDS_BY_CATEGORY[_c.category].append(_c)

TOTAL_CARDS = len(CARDS)  # 60


def get_card(name_or_id: str | int) -> Card | None:
    """Look up a card by exact id, exact name, or case-insensitive name."""
    if isinstance(name_or_id, int):
        return CARDS_BY_ID.get(name_or_id)
    if name_or_id.isdigit():
        return CARDS_BY_ID.get(int(name_or_id))
    return CARDS_BY_NAME.get(name_or_id.strip().lower())


def category_label(category: str) -> str:
    return CATEGORY_INFO.get(category, {}).get("label", category.replace("_", " ").title())


def category_emoji(category: str) -> str:
    return CATEGORY_INFO.get(category, {}).get("emoji", "🃏")
