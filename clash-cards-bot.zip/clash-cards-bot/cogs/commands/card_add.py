"""/cards add <card> [amount] — increment a card's count (defaults to +1)."""

from discord import app_commands, Interaction

from . import cards_group
from cogs.utils import card_autocomplete
from data.catalog import get_card, category_emoji
from db.database import db


@cards_group.command(name="add", description="Add to a card's count (defaults to +1, useful after a pack)")
@app_commands.describe(card="Card name", amount="How many to add (use a negative number to subtract)")
@app_commands.autocomplete(card=card_autocomplete)
async def cards_add(interaction: Interaction, card: str, amount: app_commands.Range[int, -999, 999] = 1):
    found = get_card(card)
    if found is None:
        await interaction.response.send_message(
            f"Couldn't find a card called **{card}** — pick one from the autocomplete list.",
            ephemeral=True,
        )
        return

    new_count = await db.add_card_count(interaction.guild_id, interaction.user.id, found.id, amount)
    verb = "Added" if amount >= 0 else "Removed"
    await interaction.response.send_message(
        f"{category_emoji(found.category)} {verb} {abs(amount)}x **{found.name}** — now at **{new_count}**.",
        ephemeral=True,
    )
