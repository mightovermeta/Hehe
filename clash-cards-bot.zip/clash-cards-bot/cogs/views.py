"""
Discord "Components V2" layouts (Container / Section / TextDisplay / Separator).

Requires discord.py >= 2.6, which is where LayoutView and the V2 component
types shipped. If you're on an older discord.py, `pip install -U discord.py`
first or these will fail to import.

All views here follow the same shape: build the Container's children from
scratch in a `_render()` method, then on any button/select interaction,
mutate state and call `_render()` again followed by `interaction.response
.edit_message(view=self)` (or `.edit_original_response` for followups).
"""

from __future__ import annotations

import discord

from data.catalog import CARDS_BY_CATEGORY, CATEGORY_ORDER, category_emoji, category_label
from db.database import db
from cogs.utils import progress_bar, format_card_line, chunk


# --------------------------------------------------------------------- #
# /cards collection
# --------------------------------------------------------------------- #


class CollectionView(discord.ui.LayoutView):
    """Shows one category of a user's collection at a time with a dropdown to switch."""

    def __init__(self, target: discord.abc.User, owned: dict[int, int], *, viewer_id: int):
        super().__init__(timeout=180)
        self.target = target
        self.owned = owned
        self.viewer_id = viewer_id  # only the person who ran the command can change tabs
        self.category = CATEGORY_ORDER[0]

        self.container = discord.ui.Container()
        self.add_item(self.container)
        self._render()

    def _unique_owned(self) -> int:
        return len([1 for v in self.owned.values() if v > 0])

    def _render(self) -> None:
        self.container.clear_items()

        header = discord.ui.TextDisplay(
            f"### 🃏 {self.target.display_name}'s Card Collection\n"
            f"{progress_bar(self._unique_owned(), 60)} unique cards collected"
        )
        self.container.add_item(header)
        self.container.add_item(discord.ui.Separator())

        cards = CARDS_BY_CATEGORY[self.category]
        owned_in_cat = len([c for c in cards if self.owned.get(c.id, 0) > 0])
        section_header = discord.ui.TextDisplay(
            f"**{category_emoji(self.category)} {category_label(self.category)}** "
            f"— {owned_in_cat}/{len(cards)}"
        )
        self.container.add_item(section_header)

        lines = [format_card_line(c.name, c.category, self.owned.get(c.id, 0)) for c in cards]
        # Split into a couple of TextDisplays so long categories don't hit the block char limit
        for group in chunk(lines, 10):
            self.container.add_item(discord.ui.TextDisplay("\n".join(group)))

        self.container.add_item(discord.ui.Separator())
        self.container.add_item(discord.ui.ActionRow(self._category_select()))

    def _category_select(self) -> discord.ui.Select:
        select = discord.ui.Select(
            placeholder="Jump to category…",
            options=[
                discord.SelectOption(
                    label=category_label(cat),
                    value=cat,
                    emoji=category_emoji(cat),
                    default=(cat == self.category),
                )
                for cat in CATEGORY_ORDER
            ],
        )

        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.viewer_id:
                await interaction.response.send_message(
                    "Only the person who ran this command can change tabs — run `/cards collection` yourself!",
                    ephemeral=True,
                )
                return
            self.category = select.values[0]
            self._render()
            await interaction.response.edit_message(view=self)

        select.callback = callback
        return select


# --------------------------------------------------------------------- #
# /cards progress
# --------------------------------------------------------------------- #


class ProgressView(discord.ui.LayoutView):
    """Static overview of progress across all four categories."""

    def __init__(self, target: discord.abc.User, progress: dict):
        super().__init__(timeout=180)
        container = discord.ui.Container()

        container.add_item(
            discord.ui.TextDisplay(
                f"### 📊 {target.display_name}'s Progress\n"
                f"{progress_bar(progress['owned_unique'], progress['total_unique'], length=20)}\n"
                f"-# {progress['total_count']} total cards owned (including dupes)"
            )
        )
        container.add_item(discord.ui.Separator())

        lines = []
        for cat in CATEGORY_ORDER:
            cat_progress = progress["per_category"][cat]
            lines.append(
                f"{category_emoji(cat)} **{category_label(cat)}**\n"
                f"{progress_bar(cat_progress['owned'], cat_progress['total'])}"
            )
        container.add_item(discord.ui.TextDisplay("\n\n".join(lines)))

        self.add_item(container)


# --------------------------------------------------------------------- #
# /cards leaderboard
# --------------------------------------------------------------------- #


class LeaderboardView(discord.ui.LayoutView):
    def __init__(self, guild_name: str, rows: list[dict], resolve_name):
        """`resolve_name(user_id) -> str` lets the caller pass in already-fetched display names."""
        super().__init__(timeout=180)
        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay(f"### 🏆 {guild_name} Card Leaderboard"))
        container.add_item(discord.ui.Separator())

        if not rows:
            container.add_item(discord.ui.TextDisplay("Nobody has logged any cards yet — be the first with `/cards set`!"))
        else:
            medals = ["🥇", "🥈", "🥉"]
            lines = []
            for i, row in enumerate(rows):
                rank = medals[i] if i < 3 else f"`#{i + 1}`"
                name = resolve_name(row["user_id"])
                lines.append(
                    f"{rank} **{name}** — {progress_bar(row['unique_count'], 60, length=10)} "
                    f"(+{row['total_count'] - row['unique_count']} dupes)"
                )
            container.add_item(discord.ui.TextDisplay("\n".join(lines)))

        self.add_item(container)


# --------------------------------------------------------------------- #
# /cards swap
# --------------------------------------------------------------------- #


class SwapResultView(discord.ui.LayoutView):
    """Direct two-person swap check: what each side gives/gets."""

    def __init__(self, you: discord.abc.User, other: discord.abc.User, you_give: list, you_get: list):
        super().__init__(timeout=180)
        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay(f"### 🔄 Swap Check: {you.display_name} ↔ {other.display_name}"))
        container.add_item(discord.ui.Separator())

        give_text = "\n".join(f"{category_emoji(c.category)} {c.name}" for c in you_give) or "*Nothing they want yet*"
        get_text = "\n".join(f"{category_emoji(c.category)} {c.name}" for c in you_get) or "*Nothing you want yet*"

        container.add_item(discord.ui.TextDisplay(f"**You'd give:**\n{give_text}"))
        container.add_item(discord.ui.TextDisplay(f"**You'd get:**\n{get_text}"))

        if you_give and you_get:
            container.add_item(discord.ui.Separator())
            container.add_item(discord.ui.TextDisplay("✅ **This is a mutual match — go make the trade!**"))

        self.add_item(container)


class SwapCandidatesView(discord.ui.LayoutView):
    """Server-wide scan results: other members worth trading with."""

    def __init__(self, you: discord.abc.User, candidates: list[dict], resolve_name):
        super().__init__(timeout=180)
        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay(f"### 🔍 Swap Matches for {you.display_name}"))
        container.add_item(discord.ui.Separator())

        if not candidates:
            container.add_item(
                discord.ui.TextDisplay(
                    "No matches yet. Add cards with `/cards offer add` and cards you want with "
                    "`/cards wishlist add` so others can find you too."
                )
            )
        else:
            from data.catalog import get_card

            blocks = []
            for cand in candidates:
                name = resolve_name(cand["user_id"])
                they_give = cand.get("they_offer_you_want") or []
                you_give = cand.get("you_offer_they_want") or []
                mutual = "🤝 " if they_give and you_give else ""
                they_give_names = ", ".join(get_card(cid).name for cid in they_give if get_card(cid)) or "—"
                you_give_names = ", ".join(get_card(cid).name for cid in you_give if get_card(cid)) or "—"
                blocks.append(
                    f"{mutual}**{name}**\n"
                    f"　They offer you want: {they_give_names}\n"
                    f"　You offer they want: {you_give_names}"
                )
            container.add_item(discord.ui.TextDisplay("\n\n".join(blocks)))

        self.add_item(container)


# --------------------------------------------------------------------- #
# /cards reset — confirmation
# --------------------------------------------------------------------- #


class ConfirmResetView(discord.ui.LayoutView):
    def __init__(self, user_id: int, guild_id: int):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.guild_id = guild_id
        self.confirmed: bool | None = None

        container = discord.ui.Container(accent_colour=discord.Colour.red())
        container.add_item(
            discord.ui.TextDisplay(
                "### ⚠️ Reset your collection?\n"
                "This sets every card back to 0. This **cannot** be undone."
            )
        )

        confirm = discord.ui.Button(label="Reset everything", style=discord.ButtonStyle.danger)
        cancel = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        confirm.callback = self._on_confirm
        cancel.callback = self._on_cancel
        container.add_item(discord.ui.ActionRow(confirm, cancel))

        self.add_item(container)

    async def _guard(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("This confirmation isn't for you.", ephemeral=True)
            return False
        return True

    async def _on_confirm(self, interaction: discord.Interaction):
        if not await self._guard(interaction):
            return
        await db.reset_collection(self.guild_id, self.user_id)
        self.confirmed = True
        self.clear_items()
        container = discord.ui.Container(accent_colour=discord.Colour.green())
        container.add_item(discord.ui.TextDisplay("### ✅ Collection reset.\nEvery card is back to 0."))
        self.add_item(container)
        self.stop()
        await interaction.response.edit_message(view=self)

    async def _on_cancel(self, interaction: discord.Interaction):
        if not await self._guard(interaction):
            return
        self.confirmed = False
        self.clear_items()
        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay("Cancelled — nothing was changed."))
        self.add_item(container)
        self.stop()
        await interaction.response.edit_message(view=self)
