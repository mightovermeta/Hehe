"""/cards collection [user] — browse a collection by category."""

from discord import app_commands, Interaction, User

from . import cards_group
from cogs.views import CollectionView
from db.database import db


@cards_group.command(name="collection", description="View your (or someone else's) card collection")
@app_commands.describe(user="Whose collection to view (defaults to you)")
async def cards_collection(interaction: Interaction, user: User = None):
    target = user or interaction.user
    owned = await db.get_collection(interaction.guild_id, target.id)
    view = CollectionView(target, owned, viewer_id=interaction.user.id)
    await interaction.response.send_message(view=view)
