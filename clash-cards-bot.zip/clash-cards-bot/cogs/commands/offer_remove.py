"""/cards offer remove <card> — pull a card off your trade offers."""

from discord import app_commands, Interaction

from . import offer_group
from cogs.utils import card_autocomplete
from data.catalog import get_card
from db.database import db


@offer_group.command(name="remove", description="Remove a card from your trade offers")
@app_commands.describe(card="Card name")
@app_commands.autocomplete(card=card_autocomplete)
async def offer_remove_cmd(interaction: Interaction, card: str):
    found = get_card(card)
    if found is None:
        await interaction.response.send_message(
            f"Couldn't find a card called **{card}** — pick one from the autocomplete list.",
            ephemeral=True,
        )
        return

    removed = await db.offer_remove(interaction.guild_id, interaction.user.id, found.id)
    if removed:
        msg = f"Removed **{found.name}** from your offers."
    else:
        msg = f"**{found.name}** wasn't in your offers."
    await interaction.response.send_message(msg, ephemeral=True)
