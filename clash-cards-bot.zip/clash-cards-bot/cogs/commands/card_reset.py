"""/cards reset — wipe your whole collection, behind a confirm/cancel prompt."""

from discord import Interaction

from . import cards_group
from cogs.views import ConfirmResetView


@cards_group.command(name="reset", description="Reset your entire card collection back to 0 (asks to confirm first)")
async def cards_reset(interaction: Interaction):
    view = ConfirmResetView(user_id=interaction.user.id, guild_id=interaction.guild_id)
    await interaction.response.send_message(view=view, ephemeral=True)
